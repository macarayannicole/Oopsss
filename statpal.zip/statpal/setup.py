from pathlib import Path

from setuptools import find_packages, setup

setup(
    name="statpal",  # check it is free on PyPI; rename if taken
    version="0.1.0",
    description="A small OOP toolkit for descriptive statistics.",
    long_description=Path("README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    author="OOP Group",
    packages=find_packages(exclude=["tests*"]),
    install_requires=["pandas>=1.5", "numpy>=1.23"],
    python_requires=">=3.8",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering",
    ],
)
