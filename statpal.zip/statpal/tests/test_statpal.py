import unittest

import numpy as np
import pandas as pd

from statpal import DescriptiveStats, Statistic, StatsReport, utils


class TestStatistic(unittest.TestCase):
    def test_encapsulation(self):
        s = Statistic("x")
        self.assertEqual(s.name, "x")
        with self.assertRaises(AttributeError):
            s.name = "y"

    def test_compute_counts_non_missing(self):
        self.assertEqual(Statistic().compute([1, 2, np.nan]), 2)

    def test_dunders(self):
        self.assertIn("Statistic", repr(Statistic("x")))
        self.assertEqual(Statistic("x"), Statistic("x"))
        self.assertNotEqual(Statistic("x"), Statistic("y"))
        self.assertEqual(len({Statistic("x"), Statistic("x")}), 1)


class TestDescriptiveStats(unittest.TestCase):
    def setUp(self):
        self.d = DescriptiveStats()
        self.v = [1, 2, 2, 3, 4]

    def test_inheritance(self):
        self.assertTrue(issubclass(DescriptiveStats, Statistic))

    def test_methods(self):
        self.assertEqual(self.d.mean(self.v), 2.4)
        self.assertEqual(self.d.median(self.v), 2.0)
        self.assertEqual(self.d.mode(self.v), 2.0)
        self.assertEqual(self.d.variance(self.v), 1.3)
        self.assertEqual(self.d.std(self.v), 1.14)
        self.assertEqual(self.d.value_range(self.v), 3.0)

    def test_compute_polymorphism(self):
        result = self.d.compute(self.v)
        self.assertEqual(result["mean"], 2.4)
        self.assertEqual(result["count"], 5)
        self.assertIsInstance(Statistic().compute(self.v), int)

    def test_ignores_missing(self):
        self.assertEqual(self.d.mean([1, np.nan, 3]), 2.0)

    def test_errors(self):
        with self.assertRaises(ValueError):
            self.d.mean([])
        with self.assertRaises(TypeError):
            self.d.mean(["a", "b"])

    def test_decimals_and_eq(self):
        self.assertEqual(DescriptiveStats(1).decimals, 1)
        self.assertEqual(DescriptiveStats(), DescriptiveStats())
        self.assertNotEqual(DescriptiveStats(1), DescriptiveStats(2))


class TestStatsReport(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame({"a": [1, 2, 3], "b": [2, 4, 6], "c": ["x", "y", "z"]})

    def test_run(self):
        r = StatsReport(self.df, [DescriptiveStats()])
        out = r.run()
        self.assertEqual(list(out.index), ["a", "b"])
        self.assertEqual(out.loc["b", "mean"], 4.0)

    def test_mixed_statistics(self):
        out = StatsReport(self.df).add(Statistic()).run(["a"])
        self.assertEqual(out.loc["a", "count"], 3)

    def test_dunders(self):
        r = StatsReport(self.df).add(Statistic()).add(DescriptiveStats())
        self.assertEqual(len(r), 2)
        self.assertIsInstance(r[1], DescriptiveStats)
        self.assertEqual(len(list(r)), 2)
        self.assertIn("StatsReport", repr(r))

    def test_bad_inputs(self):
        with self.assertRaises(TypeError):
            StatsReport([1, 2])
        with self.assertRaises(TypeError):
            StatsReport(self.df).add("nope")

    def test_data_is_copy(self):
        r = StatsReport(self.df)
        copy = r.data
        copy.loc[0, "a"] = 99
        self.assertEqual(r.data.loc[0, "a"], 1)


class TestUtils(unittest.TestCase):
    def test_correlation(self):
        self.assertEqual(utils.correlation([1, 2, 3], [2, 4, 6]), 1.0)
        self.assertEqual(utils.correlation([1, 2, 3], [3, 2, 1], "spearman"), -1.0)
        with self.assertRaises(ValueError):
            utils.correlation([1, 2], [1, 2], "bogus")

    def test_matrix_and_columns(self):
        df = pd.DataFrame({"a": [1, 2, 3], "b": [3, 2, 1], "c": list("xyz")})
        self.assertEqual(utils.numeric_columns(df), ["a", "b"])
        self.assertEqual(utils.correlation_matrix(df).loc["a", "b"], -1.0)

    def test_zscores_outliers_frequency(self):
        self.assertAlmostEqual(utils.zscores([1, 2, 3]).mean(), 0.0)
        self.assertEqual(list(utils.find_outliers([1, 2, 3, 2, 1, 100])), [100])
        ft = utils.frequency_table(["a", "a", "b"])
        self.assertEqual(ft.loc["a", "count"], 2)


if __name__ == "__main__":
    unittest.main()
