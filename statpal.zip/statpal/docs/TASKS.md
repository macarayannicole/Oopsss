# Task assignment

Leader: MACARAYAN, Nicole Angel D

| Member | Role | Code | Other tasks | Report |
|---|---|---|---|---|
| MACARAYAN, Nicole Angel D | Leader + report class | `statpal/report.py` (`StatsReport`) | GitHub repo, collaborators, branches and PRs, review and merge, deadlines, submissions, Phase 4 cleanup and final commits | Report 1 |
| AMPER, Charles Randolph P | Child class + helpers | `statpal/descriptive.py` (`DescriptiveStats`), `statpal/utils.py` | | Report 2 |
| MITUMOG, Anera P | Parent class (simplest) | `statpal/base.py` (`Statistic`) | UML diagram (`docs/uml.md`), docstrings for own code | Report 4 |
| RAYOS, Chainmark B | Tests and demo | `tests/test_statpal.py`, `demo.py` | Check that all 3 classes work together | Report 3 |
| UBANAN, Kimberly M | Docs and publishing | `README.md`, `LICENSE`, `setup.py`, `requirements.txt` | TestPyPI/PyPI upload, `pip install` check, presentation slides | Report 5 |

Everyone: docstrings for own code, own commits via branch + pull request,
own Peer Evaluation Form each phase, notes/screenshots to the report writer,
attend meetings, present about 1 minute on your own part.
