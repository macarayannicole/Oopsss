# Class diagram (Mermaid)

```mermaid
classDiagram
    class Statistic {
        -_name
        +name
        +compute(values)
        +__repr__()
        +__eq__()
        +__hash__()
    }
    class DescriptiveStats {
        -_decimals
        +decimals
        +mean(values)
        +median(values)
        +mode(values)
        +variance(values)
        +std(values)
        +value_range(values)
        +compute(values)
    }
    class StatsReport {
        -_data
        -_statistics
        +data
        +add(statistic)
        +run(columns)
        +__len__()
        +__iter__()
        +__getitem__()
        +__repr__()
    }
    Statistic <|-- DescriptiveStats
    StatsReport o-- Statistic : contains
```
