"""Demo of statpal on a small dataset."""

import pandas as pd

from statpal import DescriptiveStats, Statistic, StatsReport
from statpal.utils import (correlation, correlation_matrix, find_outliers,
                           frequency_table, zscores)

df = pd.DataFrame({
    "hours_studied": [1, 2, 3, 4, 5, 6, 7, 8],
    "score": [55, 60, 65, 70, 74, 80, 85, 99],
    "age": [19, 20, 20, 21, 21, 22, 22, 45],
    "program": ["BSDS", "BSDS", "BSCS", "BSIT", "BSDS", "BSCS", "BSIT", "BSDS"],
})

# Classes: Statistic (parent), DescriptiveStats (child), StatsReport (composition)
stats = DescriptiveStats()
print(stats)
print("mean score:", stats.mean(df["score"]))
print("median score:", stats.median(df["score"]))
print("std score:", stats.std(df["score"]))
print("count (parent class):", Statistic().compute(df["score"]))

report = StatsReport(df, [DescriptiveStats()])
print("\n", report, "- statistics:", len(report))
print(report.run())

# Helper functions
print("\nCorrelation hours vs score:", correlation(df["hours_studied"], df["score"]))
print(correlation_matrix(df))
print("\nOutliers in age:", list(find_outliers(df["age"])))
print("z-scores of score (first 3):", list(zscores(df["score"]).round(2)[:3]))
print(frequency_table(df["program"]))
