"""Helper functions for common statistics jobs."""

import pandas as pd


def numeric_columns(df):
    """Return the names of the numeric columns in ``df``."""
    return list(df.select_dtypes(include="number").columns)


def correlation(x, y, method="pearson"):
    """Return the correlation between two columns/Series.

    Args:
        x, y: the two Series (same length).
        method: ``'pearson'`` or ``'spearman'``.
    """
    if method not in ("pearson", "spearman"):
        raise ValueError("method must be pearson or spearman.")
    return round(float(pd.Series(x).corr(pd.Series(y), method=method)), 4)


def correlation_matrix(df, method="pearson"):
    """Return the correlation matrix of the numeric columns of ``df``."""
    return df[numeric_columns(df)].corr(method=method).round(4)


def zscores(values):
    """Return the z-score of every value (how many std. deviations from the mean)."""
    s = pd.Series(values)
    return (s - s.mean()) / s.std()


def find_outliers(values, factor=1.5):
    """Return the values outside the IQR bounds."""
    s = pd.Series(values).dropna()
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    return s[(s < q1 - factor * iqr) | (s > q3 + factor * iqr)]


def frequency_table(values):
    """Return counts and percentages for each distinct value."""
    counts = pd.Series(values).value_counts()
    return pd.DataFrame({"count": counts, "percent": (counts / counts.sum() * 100).round(2)})
