"""statpal: a small OOP toolkit for descriptive statistics."""

from .base import Statistic
from .descriptive import DescriptiveStats
from .report import StatsReport
from . import utils

__version__ = "0.1.0"
__all__ = ["Statistic", "DescriptiveStats", "StatsReport", "utils", "__version__"]
