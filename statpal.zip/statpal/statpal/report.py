"""Report that applies several statistics to a DataFrame."""

import pandas as pd

from .base import Statistic
from .utils import numeric_columns


class StatsReport:
    """Holds a DataFrame and a list of statistics, and runs them (composition).

    Args:
        data: the DataFrame to analyse.
        statistics: optional list of :class:`Statistic` objects.
    """

    def __init__(self, data, statistics=None):
        if not isinstance(data, pd.DataFrame):
            raise TypeError("data must be a pandas DataFrame.")
        self._data = data.copy()
        self._statistics = []
        for stat in (statistics or []):
            self.add(stat)

    @property
    def data(self):
        """A copy of the DataFrame being analysed."""
        return self._data.copy()

    def add(self, statistic):
        """Add a statistic and return the report (so calls can be chained)."""
        if not isinstance(statistic, Statistic):
            raise TypeError("Expected a Statistic, got %s." % type(statistic).__name__)
        self._statistics.append(statistic)
        return self

    def run(self, columns=None):
        """Apply every statistic to each numeric column.

        Returns:
            A DataFrame with one row per column and one column per result.
        """
        columns = columns or numeric_columns(self._data)
        rows = {}
        for col in columns:
            row = {}
            for stat in self._statistics:
                result = stat.compute(self._data[col])
                if isinstance(result, dict):
                    row.update(result)
                else:
                    row[stat.name] = result
            rows[col] = row
        return pd.DataFrame(rows).T

    def __len__(self):
        return len(self._statistics)

    def __iter__(self):
        return iter(self._statistics)

    def __getitem__(self, index):
        return self._statistics[index]

    def __repr__(self):
        return "StatsReport(rows=%d, statistics=%d)" % (len(self._data), len(self._statistics))
