"""Descriptive statistics for one column of numbers."""

import pandas as pd

from .base import Statistic


class DescriptiveStats(Statistic):
    """Mean, median, mode, variance, standard deviation and range.

    Child class of :class:`Statistic`; overrides :meth:`compute` to return a
    full summary.

    Args:
        decimals: number of decimals used to round the results.
    """

    def __init__(self, decimals=2):
        super().__init__("descriptive")
        self._decimals = decimals

    @property
    def decimals(self):
        """Number of decimals used for rounding."""
        return self._decimals

    def _numbers(self, values):
        series = self._clean(values)
        if series.empty:
            raise ValueError("No values to compute.")
        if not pd.api.types.is_numeric_dtype(series):
            raise TypeError("Values must be numeric.")
        return series

    def mean(self, values):
        """Return the average."""
        return round(float(self._numbers(values).mean()), self._decimals)

    def median(self, values):
        """Return the middle value."""
        return round(float(self._numbers(values).median()), self._decimals)

    def mode(self, values):
        """Return the most frequent value (the smallest if tied)."""
        return round(float(self._numbers(values).mode().iloc[0]), self._decimals)

    def variance(self, values):
        """Return the sample variance."""
        return round(float(self._numbers(values).var()), self._decimals)

    def std(self, values):
        """Return the sample standard deviation."""
        return round(float(self._numbers(values).std()), self._decimals)

    def value_range(self, values):
        """Return max minus min."""
        s = self._numbers(values)
        return round(float(s.max() - s.min()), self._decimals)

    def compute(self, values):
        """Return a dict with count, mean, median, mode, std, min, max, range."""
        s = self._numbers(values)
        d = self._decimals
        return {
            "count": int(s.count()), "mean": self.mean(s), "median": self.median(s),
            "mode": self.mode(s), "std": self.std(s),
            "min": round(float(s.min()), d), "max": round(float(s.max()), d),
            "range": self.value_range(s),
        }

    def _params(self):
        return (self._name, self._decimals)

    def __eq__(self, other):
        return type(self) is type(other) and self._params() == other._params()

    def __hash__(self):
        return hash((type(self).__name__, self._params()))
