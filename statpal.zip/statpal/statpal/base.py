"""Parent class for all statistics."""

import pandas as pd


class Statistic:
    """Base class for every statistic (the parent in the inheritance tree).

    Child classes override :meth:`compute`. Polymorphism: every statistic is
    used the same way, ``stat.compute(values)``.

    Args:
        name: a readable name for the statistic.
    """

    def __init__(self, name="count"):
        self._name = name  # protected attribute (encapsulation)

    @property
    def name(self):
        """The statistic's name (read-only accessor)."""
        return self._name

    @staticmethod
    def _clean(values):
        """Return ``values`` as a Series with missing values removed."""
        return pd.Series(values).dropna()

    def compute(self, values):
        """Return the number of non-missing values (the base statistic)."""
        return int(self._clean(values).count())

    def __repr__(self):
        return "%s(name=%r)" % (self.__class__.__name__, self._name)

    def __eq__(self, other):
        return type(self) is type(other) and self._name == other._name

    def __hash__(self):
        return hash((type(self).__name__, self._name))
