# statpal

A small object-oriented Python toolkit for **descriptive statistics**: mean, median, mode, variance, standard deviation, range, correlation and outliers. Built as the OOP Final Project.

## Installation

```bash
pip install statpal
```

## Quick start

```python
import pandas as pd
from statpal import DescriptiveStats, StatsReport
from statpal.utils import correlation

df = pd.read_csv("data.csv")

stats = DescriptiveStats()
print(stats.mean(df["score"]), stats.median(df["score"]), stats.std(df["score"]))

report = StatsReport(df, [DescriptiveStats()])
print(report.run())              # summary table for every numeric column

print(correlation(df["hours"], df["score"]))
```

See `demo.py` for a full example.

## Classes

| Class | Role |
|---|---|
| `Statistic` | Parent class with a name and a `compute()` method (counts non-missing values) |
| `DescriptiveStats(Statistic)` | Child class; overrides `compute()` to return a full summary; methods `mean`, `median`, `mode`, `variance`, `std`, `value_range` |
| `StatsReport` | Holds a DataFrame and a list of statistics; `add()` adds one, `run()` applies them to every numeric column |

## Helper functions (`statpal.utils`)

`numeric_columns`, `correlation`, `correlation_matrix`, `zscores`, `find_outliers`, `frequency_table`

## OOP concepts used

- **Classes:** 3 (`Statistic`, `DescriptiveStats`, `StatsReport`)
- **Encapsulation:** protected attributes (`_name`, `_decimals`, `_data`, `_statistics`) with `@property` accessors
- **Inheritance:** `DescriptiveStats` inherits from `Statistic`
- **Polymorphism:** `DescriptiveStats` overrides `compute()`; `StatsReport` calls `compute()` on any `Statistic`
- **Composition:** `StatsReport` holds a DataFrame and a list of `Statistic` objects
- **Dunder methods:** `__repr__`, `__eq__`, `__hash__`, `__len__`, `__iter__`, `__getitem__`

UML diagram: `docs/uml.md`.

## Testing

```bash
python -m unittest discover tests
```

## Contributors

AMPER, Charles Randolph P; MACARAYAN, Nicole Angel D; MITUMOG, Anera P; RAYOS, Chainmark B; UBANAN, Kimberly M

## License

MIT
