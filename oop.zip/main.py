
from statify import Dataset, StatisticalSummary

# Create a numerical dataset
data = Dataset([10, 20, 20, 30, 40])

# Display the dataset
print("Original Dataset:", data.get_data())

# Add another value
data.add_data(50)

print("Updated Dataset:", data.get_data())

# Generate statistical report
report = StatisticalSummary(data.get_data())
report.display_report()
