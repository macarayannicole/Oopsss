
from collections import Counter


class StatisticalAnalyzer:
    """Base class for statistical analysis."""

    def __init__(self, data):
        """Initialize the analyzer with numerical data."""
        self.data = list(data)

        if not self.data:
            raise ValueError("Dataset cannot be empty.")

        if any(
            not isinstance(x, (int, float)) or isinstance(x, bool)
            for x in self.data
        ):
            raise ValueError("Dataset must contain numbers only.")


class CentralTendency(StatisticalAnalyzer):
    """Calculate measures of central tendency."""

    def mean(self):
        """Calculate and return the arithmetic mean."""
        return sum(self.data) / len(self.data)

    def median(self):
        """Calculate and return the median."""
        sorted_data = sorted(self.data)
        n = len(sorted_data)
        mid = n // 2

        if n % 2 == 0:
            return (sorted_data[mid - 1] + sorted_data[mid]) / 2

        return sorted_data[mid]

    def mode(self):
        """Calculate and return the mode or modes."""
        counts = Counter(self.data)
        highest = max(counts.values())

        if highest == 1:
            return None

        return [
            value for value, count in counts.items()
            if count == highest
        ]