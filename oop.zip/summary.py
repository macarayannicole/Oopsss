
from central_tendency import CentralTendency
from variability import Variability
from distribution import Distribution


class StatisticalSummary:
    """Generate a complete statistical report."""

    def __init__(self, data):
        """Initialize statistical analysis objects."""
        self.data = list(data)

        if not self.data:
            raise ValueError("Dataset cannot be empty.")

        self.central = CentralTendency(self.data)
        self.variability = Variability(self.data)
        self.distribution = Distribution(self.data)

    def summarize(self):
        """Return all statistical measurements in a dictionary."""
        return {
            "Count": len(self.data),
            "Minimum": min(self.data),
            "Maximum": max(self.data),
            "Mean": self.central.mean(),
            "Median": self.central.median(),
            "Mode": self.central.mode(),
            "Range": self.variability.data_range(),
            "Population Variance": self.variability.variance(),
            "Population Standard Deviation":
                self.variability.standard_deviation(),
            "Quartiles": self.distribution.quartiles(),
            "Skewness": self.distribution.skewness()
        }

    def display_report(self):
        """Print the statistical summary."""
        print("\n========== STATIFY STATISTICAL REPORT ==========")

        for name, value in self.summarize().items():
            print(f"{name}: {value}")

        print("================================================")