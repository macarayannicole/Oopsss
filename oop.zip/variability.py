
import math
from central_tendency import StatisticalAnalyzer


class Variability(StatisticalAnalyzer):
    """Calculate measures of data variability."""

    def data_range(self):
        """Calculate the difference between maximum and minimum."""
        return max(self.data) - min(self.data)

    def variance(self, sample=False):
        """
        Calculate variance.

        Args:
            sample (bool): If True, calculate sample variance.
                           Otherwise, calculate population variance.
        """
        n = len(self.data)

        if sample and n < 2:
            raise ValueError("Sample variance requires at least 2 values.")

        average = sum(self.data) / n
        divisor = n - 1 if sample else n

        return sum((x - average) ** 2 for x in self.data) / divisor

    def standard_deviation(self, sample=False):
        """Calculate the standard deviation."""
        return math.sqrt(self.variance(sample))