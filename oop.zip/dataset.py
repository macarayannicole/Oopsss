class Dataset:
    """Manage and store numerical datasets."""

    def __init__(self, data=None):
        """Initialize the dataset."""
        self.__data = []

        if data is not None:
            self.add_multiple(data)

    def add_data(self, value):
        """Add one numerical value to the dataset."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise ValueError("Only numerical values are allowed.")

        self.__data.append(value)

    def add_multiple(self, values):
        """Add multiple numerical values."""
        for value in values:
            self.add_data(value)

    def remove_data(self, value):
        """Remove a value from the dataset."""
        self.__data.remove(value)

    def get_data(self):
        """Return a copy of the dataset."""
        return self.__data.copy()

    def count(self):
        """Return the number of values."""
        return len(self.__data)

    def clear(self):
        """Remove all values from the dataset."""
        self.__data.clear()

    def __len__(self):
        """Return the dataset length."""
        return len(self.__data)