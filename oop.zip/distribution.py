
from collections import Counter
from central_tendency import StatisticalAnalyzer


class Distribution(StatisticalAnalyzer):
    """Analyze the distribution of numerical data."""

    def frequency(self):
        """Return the frequency of each value."""
        return dict(Counter(self.data))

    def quartiles(self):
        """Calculate Q1, Q2, and Q3 using the median-of-halves method."""
        values = sorted(self.data)
        n = len(values)

        def get_median(items):
            """Calculate the median of a list."""
            size = len(items)
            middle = size // 2

            if size % 2 == 0:
                return (items[middle - 1] + items[middle]) / 2

            return items[middle]

        q2 = get_median(values)

        if n == 1:
            return {"Q1": values[0], "Q2": q2, "Q3": values[0]}

        if n % 2 == 0:
            lower = values[:n // 2]
            upper = values[n // 2:]
        else:
            lower = values[:n // 2]
            upper = values[n // 2 + 1:]

        q1 = get_median(lower)
        q3 = get_median(upper)

        return {"Q1": q1, "Q2": q2, "Q3": q3}

    def percentile(self, percent):
        """Calculate a percentile using linear interpolation."""
        if not 0 <= percent <= 100:
            raise ValueError("Percent must be between 0 and 100.")

        values = sorted(self.data)
        position = (len(values) - 1) * percent / 100

        lower = int(position)
        upper = min(lower + 1, len(values) - 1)

        fraction = position - lower

        return (
            values[lower] * (1 - fraction)
            + values[upper] * fraction
        )

    def skewness(self):
        """Calculate population moment coefficient of skewness."""
        n = len(self.data)
        mean = sum(self.data) / n

        variance = sum((x - mean) ** 2 for x in self.data) / n

        if variance == 0:
            return 0.0

        third_moment = sum(
            (x - mean) ** 3 for x in self.data
        ) / n

        return third_moment / (variance ** 1.5)